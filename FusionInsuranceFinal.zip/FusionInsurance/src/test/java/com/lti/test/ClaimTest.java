package com.lti.test;

import static org.junit.Assert.assertNotNull;
import javax.transaction.Transactional;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import com.lti.entity.ClaimInsurance;
import com.lti.repository.GenericRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
@Rollback(false)
@AutoConfigureTestDatabase(replace=Replace.NONE)
public class ClaimTest {
	
	@Autowired(required=true)
	private GenericRepository genericRepository;
	
	@Test
	@Transactional
	public void claimInsurance() {
		ClaimInsurance claim=new ClaimInsurance();
		claim.setMobileNumber(9789465213L);
		claim.setReasonToClaim("Natural Disaster");
		assertNotNull(claim);
		genericRepository.insert(claim);
	}
}
