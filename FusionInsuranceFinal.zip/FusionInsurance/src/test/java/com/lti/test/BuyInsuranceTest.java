package com.lti.test;

import static org.junit.Assert.assertNotNull;
import javax.transaction.Transactional;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import com.lti.entity.BuyInsurance;
import com.lti.entity.Registration;
import com.lti.repository.GenericRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
@Rollback(false)
@AutoConfigureTestDatabase(replace=Replace.NONE)
public class BuyInsuranceTest {
	
		@Autowired(required=true)
		private GenericRepository genericRepository;
		
		@Test
		@Transactional
		public void buyInsurance() {
			BuyInsurance buy=new BuyInsurance();
			buy.setPlanDuration(2);
			buy.setPlanType(1); 
	        buy.setVehicleType("Two wheeler");
			buy.setVehicleModel("Ferrari234");
			buy.setDrivingLicence(3453L);
			buy.setEngineNumber(345);
			assertNotNull(buy);
			genericRepository.insert(buy);
		}

		@Test
		@Transactional
		public void fetchAllUser() {
			Registration register1=new Registration();
			register1.getFirstName();
			register1.getLastName();
			register1.getEmail();
			register1.getPassword();
			assertNotNull(register1);
			genericRepository.fetchAll(Registration.class);	
		}
}

		
	
	
	
	
	
	
	
	
	


