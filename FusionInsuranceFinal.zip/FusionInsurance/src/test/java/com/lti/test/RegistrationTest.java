package com.lti.test;

import static org.junit.Assert.assertNotNull;
import javax.transaction.Transactional;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import com.lti.entity.Registration;
import com.lti.repository.GenericRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
@Rollback(false)
@AutoConfigureTestDatabase(replace=Replace.NONE)
public class RegistrationTest {
	
		@Autowired(required=true)
		private GenericRepository genericRepository;
		
		@Test
		@Transactional
		public void registerUser() {
			Registration register=new Registration();
			register.setUserName("AshwiniAmbekar");
			register.setFirstName("Ashwini");
			register.setLastName("Ambekar");
			register.setGender("F");
			register.setMobile(1484561L);
			register.setEmail("ash19@gmail.com");
			register.setPassword("Ash@19");
			register.setAddress("Pune");
			register.setState("MH");
			register.setCity("Pune");
			assertNotNull(register);
			genericRepository.insert(register);
		}

		@Test
		@Transactional
		public void fetchAllUser() {
			Registration register1=new Registration();
			register1.getUserName();
			register1.getFirstName();
			register1.getLastName();
			register1.getGender();
			register1.getMobile();
			register1.getEmail();
			register1.getPassword();
			register1.getAddress();
			register1.getState();
			register1.getCity();
			genericRepository.fetchAll(Registration.class);	
		}
		
	}
	
	
	
	
	
	
	
	
	


