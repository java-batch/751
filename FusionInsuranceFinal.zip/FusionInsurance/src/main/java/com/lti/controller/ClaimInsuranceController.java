package com.lti.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.lti.entity.ClaimInsurance;
import com.lti.service.ClaimInsuranceService;

@CrossOrigin
@RestController
public class ClaimInsuranceController {

	@Autowired(required = true)
	private ClaimInsuranceService claimInsuranceService;

	@RequestMapping(path = "/claim/add", method = RequestMethod.POST)
	public boolean addIntoService(@RequestBody ClaimInsurance claimInsurance) {
		claimInsuranceService.add(claimInsurance);
		return true;
	}
	
	@RequestMapping(path = "/claim/fetch/all", method = RequestMethod.GET)
	public List<ClaimInsurance> fetchAllFromService() {
		return claimInsuranceService.fetchAll();
	}

	@RequestMapping(path = "/claim/fetch/{userid}", method = RequestMethod.GET)
	public List<ClaimInsurance> fetchAllFromService(@PathVariable int userid) {
		return claimInsuranceService.fetchAll(userid);
	}
}
