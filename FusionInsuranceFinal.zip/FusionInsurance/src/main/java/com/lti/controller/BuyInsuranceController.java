package com.lti.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.lti.entity.BuyInsurance;
import com.lti.service.BuyInsuranceService;

@CrossOrigin
@RestController
public class BuyInsuranceController {

	@Autowired(required = true)
	private BuyInsuranceService buyInsuranceService;
  
	@RequestMapping(path = "/buy/add", method = RequestMethod.POST)
	public boolean addIntoService(@RequestBody BuyInsurance buyInsurance) {
		System.out.println(buyInsurance.getRegistration().getUserId());
		buyInsuranceService.add(buyInsurance);
		return true;
	}

	@RequestMapping(path = "/buy/all", method = RequestMethod.GET)
	public List<BuyInsurance> fetchAllFromService() {
		return buyInsuranceService.fetchAll();
	}
}
