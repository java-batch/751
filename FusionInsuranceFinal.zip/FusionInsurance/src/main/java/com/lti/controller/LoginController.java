package com.lti.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.dto.LoginDTO;
import com.lti.response.ResponseDTO;
import com.lti.service.LoginService;

@CrossOrigin
@RestController
public class LoginController {

	@Autowired
	private LoginService loginService;

	@CrossOrigin
	@RequestMapping(path = "/login/verify", method = RequestMethod.POST)
	public ResponseDTO verify(@RequestBody LoginDTO login) {
		
		ResponseDTO responseDTO=loginService.confirmLogin(login);
		return responseDTO;
		
	}
}