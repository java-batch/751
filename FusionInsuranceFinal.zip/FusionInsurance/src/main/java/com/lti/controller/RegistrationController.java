package com.lti.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.lti.entity.Registration;
import com.lti.service.RegistrationService;

@CrossOrigin
@RestController
public class RegistrationController {

	@Autowired(required = true)
	private RegistrationService registrationService;

	@RequestMapping(path = "/registration/add", method = RequestMethod.POST)
	public boolean addIntoService(@RequestBody Registration registration) {
		registrationService.add(registration);
		return true;
	
	}

	@RequestMapping(path = "/registration/all", method = RequestMethod.GET)
	public List<Registration> fetchAllFromService() {
		return registrationService.fetchAll();
	}
}
