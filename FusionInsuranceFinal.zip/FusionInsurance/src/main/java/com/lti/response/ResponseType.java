package com.lti.response;

public enum ResponseType {

	VERIFIED, NOTVERIFIED,ERROR;
	
}
