package com.lti.repository;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
//import com.lti.entity.BuyInsurance;
//import com.lti.entity.ClaimInsurance;
import com.lti.entity.Registration;

@Repository
public class GenericRepository {

	@PersistenceContext
	protected EntityManager entityManager;

	@Transactional
	public void insert(Object obj) {
		entityManager.merge(obj);
	}
	
	@Transactional
	public <E> List<E> fetchAll(Class<E> classname) {
		Query q = entityManager.createQuery("select obj from " + classname.getName() + " as obj");
		return q.getResultList();
	}

	@Transactional
	public <E> E fetchById(Class<E> classname, Object pk) { // for all type of data
		E e = entityManager.find(classname, pk);
		return e;
	}
	
	
	
}
