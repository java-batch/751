package com.lti.repository;

import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.lti.entity.ClaimInsurance;

@Repository
public class ClaimRepository extends GenericRepository {

	public List<ClaimInsurance> fetchAll(int userid) {
		Query q = entityManager.createQuery("select c from ClaimInsurance c where c.registration.userid = :id");
		q.setParameter("id", userid);
		return q.getResultList();
	}

}
