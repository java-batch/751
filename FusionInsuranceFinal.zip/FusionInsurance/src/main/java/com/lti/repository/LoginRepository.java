package com.lti.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.lti.dto.LoginDTO;
import com.lti.entity.Registration;

@Repository
public class LoginRepository extends GenericRepository {

	@PersistenceContext
	protected EntityManager entityManager;

	@Transactional
	public Registration fetchUser(LoginDTO loginDTO) {
		Query query = entityManager.createQuery(
				"Select user from Registration as user where user.email=:email and user.password=:password ");
		query.setParameter("email", loginDTO.getEmail());
		query.setParameter("password", loginDTO.getPassword());

		return (Registration) query.getSingleResult();
	}

	
}
