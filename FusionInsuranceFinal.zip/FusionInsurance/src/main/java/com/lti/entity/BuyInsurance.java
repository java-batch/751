package com.lti.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class BuyInsurance {

	@Id
	@GeneratedValue
	private int id;
	
	private int planDuration;
	private int planType;
    private String vehicleType;
	private String vehicleModel;
	private Long drivingLicence;
	private int engineNumber;
	
	@ManyToOne
	@JoinColumn(name = "userid")
	private Registration registration;

	public Registration getRegistration() {
		return registration;
	}
	public void setRegistration(Registration registration) {
		this.registration = registration;
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public int getPlanDuration() {
		return planDuration;
	}
    
	public void setPlanDuration(int planDuration) {
		this.planDuration = planDuration;
	}
	public int getPlanType() {
		return planType;
	}

	public void setPlanType(int planType) {
		this.planType = planType;
	}

	public String getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}

	public String getVehicleModel() {
		return vehicleModel;
	}

	public void setVehicleModel(String vehicleModel) {
		this.vehicleModel = vehicleModel;
	}

	public Long getDrivingLicence() {
		return drivingLicence;
	}

	public void setDrivingLicence(Long drivingLicence) {
		this.drivingLicence = drivingLicence;
	}

	public int getEngineNumber() {
		return engineNumber;
	}

	public void setEngineNumber(int engineNumber) {
		this.engineNumber = engineNumber;
	}

		
}
