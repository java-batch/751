package com.lti.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class ClaimInsurance {
	
	@Id
	@GeneratedValue
	private int id;
	
	private Long mobileNumber;
	private String ReasonToClaim;
	
	private char approved = 'N';
	
	@ManyToOne
	@JoinColumn(name = "userid")
	private Registration registration;
	
	public Registration getRegistration() {
		return registration;
	}
	public void setRegistration(Registration registration) {
		this.registration = registration;
	}
	public Long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getReasonToClaim() {
		return ReasonToClaim;
	}

	public void setReasonToClaim(String reasonToClaim) {
		ReasonToClaim = reasonToClaim;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public char getApproved() {
		return approved;
	}
	public void setApproved(char approved) {
		this.approved = approved;
	}
	
}
