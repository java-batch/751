package com.lti.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.entity.BuyInsurance;
import com.lti.repository.GenericRepository;

@Service
public class BuyInsuranceService {

	@Autowired(required=true)
	private GenericRepository genericRepository;
	
    @Transactional
	public void add(BuyInsurance buyInsurance) {
		genericRepository.insert(buyInsurance);	
	}

	public List<BuyInsurance> fetchAll() {
		return genericRepository.fetchAll(BuyInsurance.class);
	}
}
