package com.lti.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.entity.ClaimInsurance;
import com.lti.repository.ClaimRepository;

@Service
public class ClaimInsuranceService {
	
	@Autowired
	private ClaimRepository claimRepository;
	
	@Transactional
	public void add(ClaimInsurance claimInsurance) {
		claimRepository.insert(claimInsurance);	
	}
	
	public List<ClaimInsurance> fetchAll() {
		return claimRepository.fetchAll(ClaimInsurance.class);
	}
	
	public List<ClaimInsurance> fetchAll(int userid) {
		return claimRepository.fetchAll(userid);
	}
	
	
}
