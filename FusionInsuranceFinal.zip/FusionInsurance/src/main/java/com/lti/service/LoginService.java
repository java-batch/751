package com.lti.service;

import java.util.List;

import javax.persistence.PersistenceException;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dto.LoginDTO;
import com.lti.entity.Registration;
import com.lti.repository.LoginRepository;
import com.lti.response.ResponseDTO;
import com.lti.response.ResponseType;

@Service
public class LoginService {

	@Autowired
	private LoginRepository loginRepository;

	@Transactional
	public List<Registration> fetchAll() {
		return loginRepository.fetchAll(Registration.class);
	}

	@Transactional
	public ResponseDTO confirmLogin(LoginDTO loginDto) {
		ResponseDTO responseDTO = new ResponseDTO();
		
		try {
			Registration r = loginRepository.fetchUser(loginDto);
			if(r != null) {
				responseDTO.setResponseType(ResponseType.VERIFIED);
				responseDTO.setEmail(r.getEmail());
				responseDTO.setName(r.getFirstName() + " " + r.getLastName());
				responseDTO.setUserid(r.getUserId());
			}
			else
				responseDTO.setResponseType(ResponseType.NOTVERIFIED);
			return responseDTO;
		} catch (Exception e) {
			e.printStackTrace();
			responseDTO.setResponseType(ResponseType.ERROR);
			return responseDTO;
		}
	}
}
