package com.lti.training.Repository;

import org.springframework.stereotype.Repository;

@Repository("orderRepo")
public class OrderRepo extends GenericRepository {

	
}