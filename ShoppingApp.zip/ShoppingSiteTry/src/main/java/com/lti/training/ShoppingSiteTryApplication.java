package com.lti.training;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingSiteTryApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingSiteTryApplication.class, args);
	}

}

