package com.lti.training.Repository;

import org.springframework.stereotype.Repository;

@Repository("cartRepo")
public class CartRepo extends GenericRepository {

}