package com.lti.training.entity.enums;

public enum Category {
HOME_APPLANCES,FASHION,FOOTWARE,MOBILE;
}
