package com.lti.training.entity.enums;

public enum ResponseType {
VERIFIED,ADDED,DELETED,INVALID,ERROR;
}
