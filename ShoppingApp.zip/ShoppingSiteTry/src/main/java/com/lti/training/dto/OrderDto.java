package com.lti.training.dto;

import com.lti.training.entity.Cart;

public class OrderDto {
private Cart cart;
private String paymentMode;



public Cart getCart() {
	return this.cart;
}

public void setCart(Cart cart) {
	this.cart = cart;
}

public void setPaymentMode(String paymentMode) {
	this.paymentMode = paymentMode;
}

public String getPaymentMode() {
	return this.paymentMode;
}
}
