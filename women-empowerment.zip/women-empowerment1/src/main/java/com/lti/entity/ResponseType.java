package com.lti.entity;

public enum ResponseType {

	VERIFIED, NOTVERIFIED, ERROR;

}
