package com.lti.entity;

public class Status {

	private String name;
	private String description;

}
