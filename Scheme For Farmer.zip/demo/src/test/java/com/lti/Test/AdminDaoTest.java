package com.lti.Test;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;

import com.lti.dao.AdminDao;
import com.lti.dao.FarmerDao;
import com.lti.demo.DemoApplication;
import com.lti.entity.Admin;
@RunWith(SpringRunner.class)
@SpringBootTest(classes=DemoApplication.class)
@Rollback(false)
@AutoConfigureTestDatabase(replace=Replace.NONE)
public class AdminDaoTest {

	@Autowired
	private AdminDao adminDao;
	
	@Test
	@Transactional
	public void testAdmin() {
		Admin admin=new Admin();
		admin.setEmailId("admin@gmail.com");
		admin.setPassword("admin123");
		adminDao.add(admin);
		
	}
	
	@Test
	@Transactional
	public void verifyAdmin() {
		Admin admin=new Admin();
		admin=adminDao.fetchAdmin("admin@gmail.com", "admin123");
		System.out.println(admin.getEmailId());
		System.out.println(admin.getPassword());
		System.out.println("Verified..................");
		
		
	}
	
	
	
}
