package com.lti.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dao.AdminDao;
import com.lti.dao.FarmerDao;
import com.lti.dao.FarmerLoginDao;
import com.lti.dto.AdminLoginStatus;
import com.lti.dto.FarmerLoginStatus;
import com.lti.dto.LoginDto;
import com.lti.entity.Admin;
import com.lti.entity.Farmer;



@Service

public class AdminService {
	
	@Autowired
	private AdminDao adminDao;

	@Transactional
	public void add(Admin admin) {
		adminDao.add(admin);

	}
	
	
	
	
		
		@Transactional
		public AdminLoginStatus verifyAdmin(LoginDto loginDto) {
			String email=loginDto.getEmail();
			String password=loginDto.getPassword();
			AdminLoginStatus status = new AdminLoginStatus();
			
			try {
				Admin admin = adminDao.fetchAdmin(email,password);
				status.setMessage("success");
				status.setEmailId(admin.getEmailId());
			
			}
			catch (Exception e) {
				status.setMessage("error");
				e.printStackTrace();
			}
			return status;
		}
	}

