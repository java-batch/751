package com.lti.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.lti.dao.FarmerLoginDao;
import com.lti.dto.FarmerLoginStatus;
import com.lti.dto.LoginDto;


import com.lti.entity.Farmer;


;

@Service
public class FarmerLoginService {
	@Autowired
	private FarmerLoginDao farmerLoginDao;
	
	@Transactional
	public FarmerLoginStatus verifyFarmer(LoginDto loginDto) {
		String email=loginDto.getEmail();
		String password=loginDto.getPassword();
		FarmerLoginStatus status = new FarmerLoginStatus();
		
		try {
			Farmer farmer =farmerLoginDao.fetchFarmer(email,password);
			status.setMessage("success");
			status.setFarmerId(farmer.getId());
			status.setFullName(farmer.getFullName());
		
		}
		catch (Exception e) {
			status.setMessage("error");
			e.printStackTrace();
		}
		return status;
	}
		
	
	
	}


