package com.lti.Test;
import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dao.BidderDao;
import com.lti.dao.FarmerDao;
import com.lti.demo.DemoApplication;
import com.lti.entity.Bidder;
import com.lti.entity.BiddingCrop;
import com.lti.entity.Farmer;
import com.lti.entity.FarmerCropSell;




@RunWith(SpringRunner.class)
@SpringBootTest(classes=DemoApplication.class)
@Rollback(false)
@AutoConfigureTestDatabase(replace=Replace.NONE)
public class FarmerDaoTest {
	@Autowired
	private FarmerDao farmerDao;
	
	@Transactional
	@Test
	public void checkBiddingCrop() {
		Bidder bidder=new Bidder();
		bidder.setId(1);
		FarmerCropSell farmerCropSell=new FarmerCropSell();
		farmerCropSell.setCropId(10);
	BiddingCrop bidcrop=new BiddingCrop();
	bidcrop.setBidId(1);
	bidcrop.setBidAmount(10);
	bidcrop.setBidder(bidder);
	bidcrop.setFarmerCropSell(farmerCropSell);
	farmerDao.addBid(bidcrop);
	}

	
	
	@Transactional
	@Test
	public void add() {
		Farmer farmer=new Farmer();
		farmer.setFullName("Shubha Shelar");
		farmer.setContactNo(9922341);
		farmer.setEmail("shubha.shelar@gmail.com");
		farmer.setAddress("Vishrantwadi");
		farmer.setState("Maharashtra");
		farmer.setCity("Pune");
		farmer.setPincode(411015);
		farmer.setAccno(354754);
		farmer.setIfsccode("ahk577");
		farmer.setLandArea("Pune");
		farmer.setLandAddress("Vishrantwadi");
		farmer.setLandPincode("411015");
		farmer.setAadharCard("a.pdf");
		farmer.setPanCard("p.pdf");
		farmer.setCertificate("c.pdf");
		farmer.setPassword("shweta");
		farmer.setId(1);
		farmerDao.add(farmer);
		

	}
		@Transactional
		@Test
		public void addCropSell() {
			FarmerCropSell farmerCrop = new FarmerCropSell();
			farmerCrop.setCropName("Rice");
			farmerCrop.setCropType("Kharif");
			farmerCrop.setFertilizerType("postassiumchloride and diammoniumphosphate");
			farmerCrop.setQuantity(1);
			farmerCrop.setPriceperquintal(12);
		
			

			farmerDao.addCrop(farmerCrop);
			assertEquals(12, farmerCrop.getPriceperquintal());
		}

		@Test
		@Transactional
		public void fetchCropSell() {
			List<FarmerCropSell> farmerCrop = farmerDao.fetchAll();
			for (FarmerCropSell fs : farmerCrop) {
				System.out.println(fs.getCropId() + fs.getCropName());
				assertEquals("Rice", fs.getCropName());
			}
		}
		
		
	
		
			
		}
		
		

		
			
			
				
			
			
		
		
		
		



