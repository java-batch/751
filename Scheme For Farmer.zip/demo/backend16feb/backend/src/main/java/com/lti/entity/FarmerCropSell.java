package com.lti.entity;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.lti.entity.Farmer;

@Entity

public class FarmerCropSell {
	@Id
	@GeneratedValue
	private int cropId;
	
	private String cropType;
	private String cropName;

	private String fertilizerType;
	private int quantity;
	private int priceperquintal;
	private String soilpHCertificate;
	private double currentBid;

	@ManyToOne
	@JoinColumn(name = "id")
	private Farmer farmer;

	@OneToMany(mappedBy = "farmerCropSell")
	@JsonIgnore
	private Set<BiddingCrop> bidCrop;

	public Set<BiddingCrop> getBidCrop() {
		return bidCrop;
	}

	public void setBidCrop(Set<BiddingCrop> bidCrop) {
		this.bidCrop = bidCrop;
	}

	public int getCropId() {
		return cropId;
	}

	public void setCropId(int cropId) {
		this.cropId = cropId;
	}

	public int getPriceperquintal() {
		return priceperquintal;
	}

	public void setPriceperquintal(int priceperquintal) {
		this.priceperquintal = priceperquintal;
	}

	public String getCropType() {
		return cropType;
	}

	public void setCropType(String cropType) {
		this.cropType = cropType;
	}

	public String getCropName() {
		return cropName;
	}

	public void setCropName(String cropName) {
		this.cropName = cropName;
	}

	public String getFertilizerType() {
		return fertilizerType;
	}

	public void setFertilizerType(String fertilizerType) {
		this.fertilizerType = fertilizerType;
	}


	public String getSoilpHCertificate() {
		return soilpHCertificate;
	}

	public void setSoilpHCertificate(String soilpHCertificate) {
		this.soilpHCertificate = soilpHCertificate;
	}

	

	public Farmer getFarmer() {
		return farmer;
	}

	public void setFarmer(Farmer farmer) {
		this.farmer = farmer;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getCurrentBid() {
		return currentBid;
	}

	public void setCurrentBid(double currentBid) {
		this.currentBid = currentBid;
	}
	
	

}
