package com.lti.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.lti.entity.Bidder;
import com.lti.entity.Farmer;
import com.lti.entity.Farmer;


@Repository  
public class FarmerLoginDao {

	@PersistenceContext
	private EntityManager entitymanager;
	
	@Transactional
	public void add(FarmerLoginDao login)
	{
		entitymanager.persist(login);
		
	}
	
	@Transactional
	public FarmerLoginDao fetch(int id)
{
return entitymanager.find(FarmerLoginDao.class, id);	
}
	@Transactional
	public Farmer fetchFarmer(String email ,String password){
		Query q= entitymanager.createQuery("from Farmer as obj where obj.email=?1 and obj.password=?2");
		q.setParameter(1, email);
		q.setParameter(2, password);
		return (Farmer) q.getSingleResult();
	}

}
