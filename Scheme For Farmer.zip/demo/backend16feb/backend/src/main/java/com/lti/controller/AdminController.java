package com.lti.controller;

//@RestController
public class AdminController {
	
	/*@Autowired
	private AdminService adminService;

@RequestMapping(path = "/login/admin", method = RequestMethod.POST)
	public String add(@RequestBody Admin admin) {
		adminService.add(admin);
		return "true";

}*/
}
