package com.lti.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.dao.BidderDao;
import com.lti.entity.Bidder;
import com.lti.entity.BiddingCrop;
import com.lti.entity.FarmerCropSell;
import com.lti.service.BidderService;
import com.lti.service.FarmerService;




@RestController
@CrossOrigin
public class BidderController {
	
	@Autowired(required=true)
	private BidderService bidderService;
	private FarmerService farmerService;
	
	@CrossOrigin
	@RequestMapping(path="/bidder/add", method=RequestMethod.POST)
	public boolean add(@RequestBody Bidder bidder) {
		
		bidderService.add(bidder);
		return true;
		//return "Bidder record created successfully!";
		
	}
	


	
	
}
