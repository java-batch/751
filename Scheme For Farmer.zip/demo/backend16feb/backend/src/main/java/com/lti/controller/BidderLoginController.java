package com.lti.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.dto.LoginDto;
import com.lti.dto.LoginStatus;
import com.lti.service.BidderLoginService;

@RestController
@CrossOrigin
public class BidderLoginController {
	
	@Autowired(required=true)
	private BidderLoginService bidderLoginService;
	
	@RequestMapping(path="/bidderlogin/verifybidder" , method=RequestMethod.POST)
	public LoginStatus verifyBidder(@RequestBody LoginDto login) {
		 return bidderLoginService.verifyBidder(login);
	}

}
