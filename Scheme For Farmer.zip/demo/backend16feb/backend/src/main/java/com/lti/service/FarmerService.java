package com.lti.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dao.BidderDao;
import com.lti.dao.FarmerDao;
import com.lti.dto.BiddingDto;
import com.lti.entity.Farmer;
import com.lti.entity.FarmerCropSell;
import com.lti.entity.Bidder;
import com.lti.entity.BiddingCrop;

@Service
public class FarmerService {
	
	@Autowired
	private FarmerDao farmerDao;
	
	@Autowired
	private BidderDao bidderDao;
	
//	@Autowired
//	private FarmerCropSell farmerCropSell;

	@Transactional
	public void add(Farmer farmer) {
		farmerDao.add(farmer);
		
	}
	@Transactional
	public void addCrop(FarmerCropSell farmerCrop) {
		farmerDao.addCrop(farmerCrop);
		}
	
	@Transactional
	public List<FarmerCropSell> fetchAll() {
		return farmerDao.fetchAll();

	}

	@Transactional
	public void addBid(BiddingDto biddingDto) {
			 double bidAmount = biddingDto.getBidAmount();
			 int cropId = biddingDto.getCropId();
			 int bidderId = biddingDto.getBidderId();
			 FarmerCropSell cropSell=new FarmerCropSell();
		
			 FarmerCropSell crop = farmerDao.fetchFarmerCrop(cropId);
			 System.out.println(crop.getCropId());
		double maxBid= farmerDao.addCurrentBid(crop.getCropId());
		
			if(bidAmount > maxBid) {
				BiddingCrop bid = new BiddingCrop();
				 bid.setBidAmount(bidAmount);
			farmerDao.insertFarmerSell(crop.getCropId());
				 Bidder bidder = bidderDao.fetch(bidderId);
				 bid.setBidder(bidder);
				 bid.setFarmerCropSell(crop);
				 farmerDao.addBid(bid);
				}
			else {
				cropSell.setCurrentBid(maxBid);
				
			}
	}
	}


