package com.lti.plutusloan.service;

import com.lti.plutusloan.entity.Registration;

public interface ApplicationService {

	public Registration fetchUserDetails(String emailId) ;
}
