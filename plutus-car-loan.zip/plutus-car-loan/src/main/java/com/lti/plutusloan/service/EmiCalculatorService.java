package com.lti.plutusloan.service;

import com.lti.plutusloan.dto.EmiDTO;

public interface EmiCalculatorService {

	public double calculateEmi(EmiDTO emiDTO);
}
